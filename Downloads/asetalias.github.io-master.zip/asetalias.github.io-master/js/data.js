var currentDate = new Date();

/** FlashBox **/
var flashbox;

/**Flashbox Containers */
var flashboxContainer = $(".flashbox");
var flashboxContentContainer = $(".flashBox-content");
var flashboxCloseBtn = $(".flashbox .closeBtn");
/** End Containers **/